# Предупреждение!!!
Замените файл login_manager.py библиотеки flask-login

# Введение
TecnoPy - это небольшой интернет магазин, написанный на Flask. В нем были реализованы: каталог, карточки, панель администратора, а также поисковая система.

# Скрины
```
/catalog
```
![alt text](photos/catalog.png)

```
/product-name
```
![alt text](photos/card.png)


```
/login_admin
```
![alt text](photos/login_admin.png)

```
/admin
```
![alt text](photos/admin.png)

```
/add_card
```
![alt text](photos/add_card.png)
